const express=require('express');
const chalk=require('chalk');
const path=require('path');
const jobData=require("./src/model/postJobData.js");

var app= new express();
var nav=[
    {link:'/',title:'Home'},
    {link:'/jobList',title:'Job List'},
    {link:'/postJob',title:'Post a Job'},
    {link:'/about',title:'About Us'},
    {link:'/contact',title:'Contact'},
    {link:'/login',title:'Log In'},


]
// var nav2=[
//     {}
// ]

// var nav3=[
//     {}
// ]
const cntRouter=require('./src/routes/cntRoutes')(nav);
const postJobRouter=require('./src/routes/postJobRouter')(nav);
const jobListRouter=require('./src/routes/jobListRouter')(nav);
const jobIdRouter=require("./src/routes/jobIdRouter")(nav);
const loginRouter=require("./src/routes/loginRouter")(nav);
const regRouter=require("./src/routes/regRouter")(nav);


//const ****routes=require('./src/routes/')(nav);

app.use(express.static(path.join(__dirname,"/public")));

 app.use('/contact',cntRouter);
 app.use('/postJob',postJobRouter);
 app.use('/jobList',jobListRouter);
 app.use("/jobId",jobIdRouter);
 app.use("/login",loginRouter);
 app.use("/register",regRouter);
 


//app.use('',****router)

app.set('views','./src/views');
app.set('view engine','ejs');

app.get('/',function(req,res){
    jobData.find().then(function(job_list){

        res.render('index',{
            nav,
            title:"job search",job_list
        });
    })
    
});

app.listen(3000,function(){
    console.log("port listening is"+chalk.green('3000'));
});