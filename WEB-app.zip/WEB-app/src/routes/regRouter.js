const express=require('express');//importing express

const regRouter=express.Router(); //creating router
const regData=require("../model/regmodel");
function router(nav){

regRouter.route('/')
    .get((req,res)=>{
        res.render('reg',{
            nav,
            title:'Ladder'
    });
});
regRouter.route('/add')
.get((req,res)=>{
    
    var items={

    name:req.param("name"),
    age:req.param("age"),
    gender:req.param("gender"),
    mail:req.param("email"),
    quali:req.param("quali"),
    year:req.param("year")
   
    }
    var login=new regData(items);
    login.save();
    res.redirect("/")

})
    return regRouter;
}
module.exports=router;