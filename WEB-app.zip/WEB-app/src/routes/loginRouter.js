const express=require('express');//importing express

const loginRouter=express.Router(); //creating router
const loginData=require("../model/logindata");
function router(nav){

loginRouter.route('/')
    .get((req,res)=>{
        res.render('login',{
            nav,
            title:'Ladder'
    });
});
loginRouter.route('/add')
.get((req,res)=>{
    
    var items={

    name:req.param("name"),
    quali:req.param("quali"),
    gender:req.param("gender"),
    mail:req.param("email"),
    uname:req.param("uname"),
    pwd:req.param("pass")
   
    }
    var login=new loginData(items);
    login.save();
    res.redirect("/login")

})
    return loginRouter;
}
module.exports=router;