const express=require('express');//importing express

const jobListRouter=express.Router(); //creating router
const jobData=require("../model/postJobData.js");
function router(nav){

jobListRouter.route('/')
.get((req,res)=>{
    jobData.find().then(function(job_list){
        res.render('jobList',{
            nav,
            title:'Job List',job_list
        });

    })
    
});

jobListRouter.route('/:id')
.get((req,res)=>{
    var id= req.params.id;

    jobData.findOne({_id:id}).then(function(single_job){
        res.render('jobId',{nav,title:"Job List",single_job});

    })
    
});

    return jobListRouter;
}
module.exports=router;