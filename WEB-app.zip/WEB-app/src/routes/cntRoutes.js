const express=require('express');//importing express

const cntRouter=express.Router(); //creating router
function routerNav(nav){

var contact=[
    {
        address: 'kothazhamukk,chillupuram, Japan',
        mobile: '9856452580',
        email:'thummiko@gmail.com',
        website:'www.kingini.com'
    }
]
    cntRouter.route('/')
    .get((req,res)=>{
        res.render('contact',{
            nav,
            title:'contact us',
            contact
    });
});

    return cntRouter;
}
module.exports=routerNav;