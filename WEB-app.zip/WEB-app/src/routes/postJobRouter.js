const express=require('express');//importing express

const postJobRouter=express.Router(); //creating router
const jobData=require("../model/postJobData.js");
function router(nav){

postJobRouter.route('/')
    .get((req,res)=>{
        res.render('postJob',{
            nav,
            title:'Ladder'
    });
});
postJobRouter.route('/add')
.get((req,res)=>{
    
    var items={

    Title:req.param("jobTitle"),
    cmpy:req.param("cmpy"),
    salary:req.param("salary"),
    categories:req.param("categories"),
    cities:req.param("cities"),
    hrName:req.param("hrName"),
    description:req.param("description"),
    hrEmail:req.param("hrEmail"),
    contract:req.param("contract"),
    experienceNeeded:req.param("experienceNeeded")
    }
    var job=new jobData(items);
    job.save();
    res.redirect("/jobList")

})
    return postJobRouter;
}
module.exports=router;