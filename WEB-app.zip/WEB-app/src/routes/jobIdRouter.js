const express=require('express');//importing express

const jobId=express.Router(); //creating router
function router(nav){


    jobId.route('/')
    .get((req,res)=>{
        res.render('jobId',{
            nav,
            title:'JobDetails'
    });
});

    return jobId;
}
module.exports=router;