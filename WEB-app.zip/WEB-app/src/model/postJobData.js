const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/Ladder");
const Schema=mongoose.Schema;

var newSchema=new Schema({
    
    cmpy:String,
    categories:String,
    salary:String,
    cities:String,
    hrName:String,
    description:String,
    hrEmail:String,
    contract:String,
    experienceNeeded:String

});
var jobData=mongoose.model("postJob-data",newSchema);

module.exports=jobData;