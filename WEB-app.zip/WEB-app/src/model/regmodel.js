const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/Ladder");
const Schema=mongoose.Schema;

var newSchema=new Schema({
    
    name:String,
    age:Number,
    gender:String,
    mail:String,
    quali:String,
    year:Number,
    
});

var regData=mongoose.model("job_reg_data",newSchema);


module.exports=regData;
