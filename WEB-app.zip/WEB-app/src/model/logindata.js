const mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/Ladder");
const Schema=mongoose.Schema;

var newSchema=new Schema({
    
    name:String,
    quali:String,
    gender:String,
    mail:String,
    uname:String,
    pwd:String,
    
});
var loginData=mongoose.model("user",newSchema);

module.exports=loginData;